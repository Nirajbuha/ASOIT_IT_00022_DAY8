let x=20,y=30;
var sum=x+y,
mul=x*y;
document.write("<br/>sum:",sum+"</br>mul:",mul);